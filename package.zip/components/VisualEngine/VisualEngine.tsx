"use client";

import type { Scene } from "../Scene/SceneContext";

type Props = {
  scene: Scene;
};

export default function VisualEngine({}: Props) {
  return (
    <svg
      style={{
        position: "fixed",
        inset: 0,
        width: "100vw",
        height: "100vh",
        zIndex: 9999,
        background: "blue",
      }}
      viewBox="0 0 100 100"
    >
      <circle
        cx="50"
        cy="50"
        r="10"
        fill="red"
      />
    </svg>
  );
}